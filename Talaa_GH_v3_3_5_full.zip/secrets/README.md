# Secrets — Ghana
Set Android/iOS/Backend creds in GitHub Actions.
