# Talaa GH Backend (Starter)

Same API as ZA; default port 4100.

```
cp .env.sample .env
npm i
npm run dev
```
